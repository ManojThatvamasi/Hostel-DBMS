const form = document.getElementById("form");
form.onsubmit = (e) => {
e.preventDefault();
const room = form["rmid"].value;
const bed = form["bed"].value;

//let testFailed = false;
let roomid_regExp=/^R{1}[0-9]*$/;
if(!roomid_regExp.test(room))
{
alert("Enter the Room_id correctly");
testFailed=true;
}

let bedno_regExp=/^[0-9]{1}$/;
if(!bedno_regExp.test(bed))
{
alert("Enter the number of beds correctly");
testFailed=true;
}
//if (!testFailed) {
//}
};