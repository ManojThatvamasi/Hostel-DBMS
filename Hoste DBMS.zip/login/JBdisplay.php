<!DOCTYPE html>
<html>
<head>
	<title>JOB Details</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
<div class="container">
<button class="btn btn-primary my-5">
<a href="JBinsert.php" class="text-light font-weight-bold">Add Job </a></button>
<button class="btn btn-primary my-5">
<a href="JBdetails.php" class="text-light font-weight-bold">JOB Details</a></button>

<?php if(isset($_GET['success'])) { ?>
    <div class="alert alert-success w-25" role="alert">
      <?php echo $_GET['success']; ?>
      </div>
    <?php } ?>

    <?php if(isset($_GET['update'])) { ?>
    <div class="alert alert-info w-25" role="alert">
      <?php echo $_GET['update']; ?>
      </div>
      <?php } ?>
      <?php if(isset($_GET['delete'])) { ?>
    <div class="alert alert-danger w-25" role="alert">
      <?php echo $_GET['delete']; ?>
      </div>
      <?php } ?>
        <?php if(isset($_GET['error1'])) { ?>
    <div class="alert alert-danger w-25" role="alert">
      <?php echo $_GET['error1']; ?>
      </div>
      <?php } ?>

<form action="" method="POST" class="pull-right">
<div class="row">
<div class="col-2">
<input type="text" name="search" placeholder="Enter Job Name" class="form-control"/></div>
<button class="btn btn-info font-weight-bold">SEARCH</button>   
<div class="col"><button class="btn btn-secondary"><a href="JBdisplay.php" class="text-light font-weight-bold"><-</a></button></div>
<br></div><br>
</form>

<table class="table table-hover table-bordered text-center">
  <thead>
    <tr>
      <th scope="col">JOB NAME</th>
      <th scope="col">Number Of Employees</th>
      <th scope="col">Operation</th>
    </tr>
  </thead>
  <tbody>

 <?php
session_start();
include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
    if(isset($_POST['search']))
  {
    $key=$_POST['search'];
    $sql="SELECT * from job where Job_Name like '%$key%'";
    
  }
  else
  $sql="select * from job";
 $result =mysqli_query($con,$sql);
 if($result){
 		while ($row=mysqli_fetch_assoc($result)) {
      $sl=$row['Sl_No'];
 		$jb=$row['Job_Name'];
 		$emp=$row['No_of_Emp'];
 
 		echo '<tr>
    <th scope="row">'.$jb.'</th>
      <td>'.$emp.'</td>
     
      <td>
  	<button class="btn btn-warning"><a href="JBupdate.php?updateid='.$jb.'" class="text-light">UPDATE</a></button>
  	<button class="btn btn-danger"><a href="JBdelete.php?deleteid='.$jb.'" class="text-light">DELETE</a></button>
  </td>
</tr>';
 		}
 	}
?>
  </tbody>
</table>
</div>
<center><button class="btn btn-dark font-weight-bold"><a href="boot.php" >MENU</button></center>
</body>
</html>
