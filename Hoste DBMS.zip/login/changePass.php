<?php
session_start();
include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		$sql="select * from login";
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_assoc($result);
		$UN=$row['username'];
 		$na=$row['Name'];
 		$mail=$row['Email'];
 		$ph=$row['Phone'];
  		$pas=$row['password'];

		if(isset($_POST['submit'])){

		$un=$_POST['UN'];
		$name=$_POST['name'];
		$email=$_POST['email'];
		$ph=$_POST['ph'];
		$new=$_POST['new'];
		//$old=$_POST['conf'];
		
	$sql = "UPDATE login set username='$un',Name='$name',Email='$email',Phone='$ph',password='$new'";
		if(mysqli_query($con, $sql))
		{
				header('location:changePass.php?Success=Successfully Changed');
		} else{
			die(mysqli_error($con));
			header('location:changePass.php?error=error occured');

		}
	}
		mysqli_close($con);
		?>

<!DOCTYPE html>
<html>
<head>
	<title>Upadte Login Account</title>
	<link rel="stylesheet" href="form2.css">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
	<style type="text/css">
		pre{
	font-size: 30px;
	color: red;
}
	</style>
</head>
<body><br><br>
	<div class="container">
		<form action="" method="post">
	<?php if(isset($_GET['Success'])) { ?>
    <div class="alert alert-info w-75" role="alert">
      <?php echo $_GET['Success']; ?>
      </div>
    <?php } ?>
    	<?php if(isset($_GET['error'])) { ?>
    <div class="alert alert-danger w-75" role="alert">
      <?php echo $_GET['error']; ?>
      </div>
    <?php } ?>
	
<h2 class="display-5"> Account Details..</h2>	
	<div class="row">
	<div class=" col-md-5">
		<label>User Name:</label>
		<input type="text" name="UN" class="form-control" value=<?php echo $UN;?> required>
		</div>
	<div class=" col-md-5 mb-4">
		<label>Name:</label>
		<input type="text" name="name" class="form-control" value="<?php echo $na;?>" required /></div>
	<div class=" col-md-5">
		<label>Email:</label>
		<input type="Email" name="email" class="form-control" value="<?php echo $mail;?>" required /><br>
		</div>
	<div class=" col-md-5 mb-4">
		<label>Phone</label>
		<input type="numeric" name="ph" class="form-control" value="<?php echo $ph;?>" required/>
		</div>
	<div class=" col-md-5 mb-5">
	<label>Password:</label>
			<input type="text" class="form-control" name="new" value="<?php echo $pas;?>" required/>
			</div>
	<!--<div class="col-8 mb-2">
<h2 class="display-5">Change Password..</h2></div><br><br>
		<div class="col-md-5 mb-4">
		<label>New Password:</label>
			<input type="text" class="form-control" name="new">
			</div>
	<div class=" col-md-5">
		<label>Confirm Password:</label>
			<input type="text" class="form-control" name="conf"><br>
</div>-->
	</div>

		<center><input type="submit" class="btn btn-success font-weight-bold" name="submit" value="UPDATE"></center></div></div></form>
			<br><br>
			<center>
		<button class="btn btn-dark font-weight-bold"><a href="boot.php">MENU</a></button></center>
</body>
</html>
