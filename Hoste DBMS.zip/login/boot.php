<?php
session_start();
	include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect. "
			. mysqli_connect_error());
	}
					?>

<html>
<head><title>Main</title></head>
<link rel="stylesheet"  href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link rel="stylesheet" href="boot.css">
<style type="text/css">
	::-webkit-scrollbar{
		display: none;
	}
</style>
	<body class="no-gutters">
		<!input type="checkbox" id="checkbox">
<header class="header">
	<h2 class="u-name">SIDE<b>BAR</b></h2>
	

<a href="logout.php"><i id="log" class="fa fa-sign-out fa-2x" aria-hidden="true"></i></a>
<a href="changePass.php"><i class="fa fa-user fa-3x" aria-hidden="true"></i></a>
</header>
<div class="body">
	<div class="side-navi">
	<nav class="side-bar">
		<div class="user-p">
			<img src="a.jpg">
			
		</div>
		<ul>
			<li>
				<a href="#">
					<i class="fa fa-desktop" aria-hidden="true"></i>
					<span>DashBoard</span></a>
			</li>
			<li>
				<a href="STdisplay.php">
					<i class="fa fa-graduation-cap" aria-hidden="true"></i>
					<span>Student</span></a>
			</li>
			<li>
				<a href="EMdisplay.php">
					<i class="fa fa-users" aria-hidden="true"></i>
					<span>Employee</span></a>
			</li>
			<li>
				<a href="RMdisplay.php">
					<i class="fa fa-bed" aria-hidden="true"></i>
					<span>Room</span></a>
			</li>
			<li>
				<a href="JBdisplay.php">
					<i class="fa fa-handshake-o" aria-hidden="true"></i>
					<span>Job</span></a>
			</li>
			<li>
				<a href="Fdisplay.php">
					<i class="fa fa-credit-card-alt" aria-hidden="true"></i>
					<span>Fees</span></a>
			</li>
			<li>
				<a href="MEdisplay.php">
					<i class="fa fa-cutlery" aria-hidden="true"></i>
					<span>Mess</span></a>
			</li>
		</ul>
	</nav></div>


	<section class="sec-1">
		<br>
		<b><h1>Hostel Management System</h1></b><br>
		<h5>DashBoard</h5>
		<p><b><u>ABC Boys Hostel</u></b><br>
			<br>0th cross,0-block<br>
			Managanapura Mysuru-570 000<br>
			Contact-Number:XXXXXXXXX<br>
			Email:xxx@gmail.com
</p>

<div class="row">
		
		<div class="col-xl-7 col-md-6 ">
			<div class="card bg-info text-white mb-4">
				<div class="card-body">Number of Students</div>
				<?php
				
				$sql="select * from student";
				$result=mysqli_query($con,$sql);
				if($total=mysqli_num_rows($result))
				{
					echo	'<h2 class="mb-0 text-center ">'.$total.'</h2>';
				}
				else
				{
					die(mysqli_error($con));
					echo '<h2 class="mb-0 text-center ">No data</h2>';
				}
				?>
				
					<div class="card-footer d-flex align-item-center justify-content-between">
						<a class="media text-white stretched-link" href="NoOfST.php">View Details</a>
		<div class="small text-white"><i class="fa fa-angle-right" aria-hidden="true"></i></div>
			</div>
			</div>
			</div>

			<div class="col-xl-7 col-md-6">
			<div class="card bg-info text-white mb-4" style="width: 18rem;">
				<div class="card-body">Number of Employees</div>
				<?php
				
				$sql="select * from emp";
				$result=mysqli_query($con,$sql);
				if($total=mysqli_num_rows($result))
				{
					echo	'<h2 class="mb-0 text-center ">'.$total.'</h2>';
				}
				else
				{
					die(mysqli_error($con));
					echo '<h2 class="mb-0 text-center ">No data</h2>';
				}
				?>
				
					<div class="card-footer d-flex align-item-center justify-content-between">
						<a class="medium text-white stretched-link" href="NoOfEM.php">View Details</a>
		<div class="small text-white"><i class="fa fa-angle-right" aria-hidden="true"></i></div>
			</div>
			</div>
			</div>

		</div>	
	</section>

</div>
</div>
	</body></html>