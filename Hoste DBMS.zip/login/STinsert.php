<?php
session_start();
include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		if (isset($_POST['submit'])) {
$sid=$_POST['F1'];
$name=$_POST['F2'];
$gender=$_POST['Gender'];
$dob=$_POST['F3'];
$phone=$_POST['F4'];
$email=$_POST['F5'];
$clg=$_POST['F6'];
$course=$_POST['F7'];
$room=$_POST['room'];
$vil=$_POST['F9'];
$tal=$_POST['F10'];
$dis=$_POST['F11'];
$state=$_POST['F12'];
$pc=$_POST['F13'];
$fn=$_POST['F14'];
$fnp=$_POST['F15'];
$mn=$_POST['F16'];
$mnp=$_POST['F17'];

$sql = "INSERT INTO student VALUES ('$sid','$name','$gender','$dob','$phone','$email','$clg','$course','$room','$vil','$tal','$dis','$state','$pc','$fn','$fnp','$mn','$mnp')";
		
		if(mysqli_query($con, $sql)){
			//echo "<h3>data stored in a database successfully."
			header('location:STdisplay.php?success=successfully Added');

			
		} else{
			header('location:STinsert.php?error=SID is already Exists');
			die(mysqli_error($con));
		}
	}
		// Close connection
		mysqli_close($con);
		?>
<!DOCTYPE html>s
<html>
<head>
	<style type="text/css">
		.container{
	min-height: 50vh;
	display:flex;
	justify-content: center;
	align-items: center;
	flex-direction:column;
}
.container form
{
	width:1200px;
	padding: 40px;
	border-radius: 15px;
	box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
}
.form-group
{
	margin-bottom: -35px;
}
	</style>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
	<title>Add Student Details</title>
</head>
<body>
	<div class="container">
	<h3 class=" display-5 text-center">STUDENT DETAILS</h3>
	<form action="" method="POST">
		
		 <?php if(isset($_GET['error'])) { ?>
    <div class="alert alert-danger w-25" role="alert">
      <?php echo $_GET['error']; ?>
      </div>
      <?php } ?>
      <h4 class="display-5">Add Student Information</h4>
      <div class="form-row">
<div class=" col-md-2 mb-3">
	<label>SID:</label>
	<input type="text" class="form-control" name="F1" required>
	</div>
	<div class=" col-md-4 mb-3">
	<label>Student Name:</label>
	<input type="text" name="F2" class="form-control" required>
	</div>
	<div class="col-md-3 mb-3">
	<label>Gender:</label><br>
	<input type="radio" name="Gender" value="Male" checked>Male
	<input type="radio" name="Gender" value="Female">Female
	<input type="radio" name="Gender" value="Other">Other
	</div>
	<div class=" col-md-3 mb-4">
	<label>Date Of Birt:</label>
		<input type="Date" name="F3" class="form-control" required>
	</div>
	<div class=" col-md-2 mb-1">
	<label>	Phone Number:</label>
	<input type="Number"  class="form-control" name="F4"/>
	</div>
	<div class=" col-md-4 ">
	<label>Email:</label>
		<input type="Email"  class="form-control" name="F5"><br>
	</div>
	<div class=" col-md-2 mb-1">
	<label>Room:</label>
		<?php
                        include('connection.php');
                        $class_result=mysqli_query($con,"SELECT Room_NO FROM room");
                            echo '<select name="room" class="form-control" required>';
                            echo '<option selected disabled>Select Class</option>';
                        while($row = mysqli_fetch_array($class_result)){
                            $display=$row['Room_NO'];
                            echo '<option value="'.$display.'">'.$display.'</option>';
                        }
                        echo'</select>'
                    ?>
		</div>
	<div class=" col-md-5 mb-4">
	<label>College:</label>
		<input type="text" class="form-control" name="F6"/>
	</div>
	<div class=" col-md-5 mb-3">
	<label>Course:</label>
		<input type="text" class="form-control" name="F7"/>
	</div>
	<div class=" col-md-3 mb-1">
		<label>Village/City:</label>
		<input type="text" name="F9" class="form-control" required/>
		</div>
	<div class=" col-md-2 mb-1">
		<label>Taluk:</label>
		<input type="text" name="F10" class="form-control" required/>
		</div>
	<div class=" col-md-2 mb-3">
		<label>District:</label>
		<input type="text" name="F11" class="form-control" required/>
		</div>
	<div class=" col-md-2 mb-3">
		<label>State:</label>
		<input type="text" name="F12" class="form-control" required/>
		</div>
	<div class=" col-md-2 mb-3">
		<label>PinCode:</label>
		<input type="Number" name="F13" class="form-control" required/><br>
	</div>
	<div class=" col-md-3 mb-3">
	<label>Father Name:</label>
		<input type="text" name="F14" class="form-control" required />
	</div>
	<div class=" col-md-2 mb-3">
	<label>Phone Number:</label>
		<input type="Number" name="F15" class="form-control" required />
	</div>
	<div class=" col-md-3 mb-3">
	<label>Mother Name:</label>
		<input type="text" name="F16" class="form-control" required />
	</div>
	<div class=" col-md-2 mb-3">
	<label>Phone Number:</label>
		<input type="Number"  name="F17" class="form-control" required /></div></div>
	<center><input type="submit" class="btn btn-success font-weight-bold" value="Add Student" name="submit" />
		<button class="btn btn-secondary font-weight-bold"><a href="STdisplay.php" class="text-light"><-</a></button></center>
	</form>

</body>
</html>