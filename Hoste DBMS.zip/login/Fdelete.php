<?php
session_start();
include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}

if(isset($_GET['deleteid']))
{
	$id=$_GET['deleteid'];
	$sql="delete from fees where SID='$id'";
	$result=mysqli_query($con,$sql);
	if($result)
	{
header('location:Fdisplay.php?delete=Delete Successfully');		
//echo "deleteed Sucess";
	}else
	{
		die(mysqli_error($con));
	}

}

?>