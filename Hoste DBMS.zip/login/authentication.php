<?php      
    $username = $_POST['user'];  
    $password = $_POST['pass'];  
      
        //to prevent from mysqli injection  
        $username = stripcslashes($username);  
        $password = stripcslashes($password);  
        $username = mysqli_real_escape_string($con,$username);  
        $password = mysqli_real_escape_string($con,$password);  
      
	$con=mysqli_connect("localhost","root","","login");
	//mysqli_select_db("log1");

        $result=mysqli_query("select *from login where username = '$username' and password = '$password'")
		or die("Unable to querry DB".mysqli_error());
          
        $row = mysqli_fetch_array($result);  
    
        if($row['username']== $username && $row['password']== $password )
	{  
            echo "<h1><center> Login successful </center></h1>";  
        }  
        else
	{  
            echo "<h1> Login failed. Invalid username or password.</h1>";  
        }     
?>  