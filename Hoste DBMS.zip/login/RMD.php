 <!DOCTYPE html>
<html>
<head>
	<title>ROOM Details</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<link rel="stylesheet"  href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body><br><br>
<div class="container">

<form action="" method="POST" class="pull-left">
	<h2 class="display-5">Room Details</h2>
	<br>
<div class="row">
<div class="col-7">
<input type="text" name="search" placeholder="Room No" class="form-control"/></div>
<button class="btn btn-info font-weight-bold">SEARCH</button>   
<div class="col"><button class="btn btn-secondary"><a href="RMD.php" class="text-light font-weight-bold"><-</a></button></div>

<br></div><br>
</form>

<table class="table table-hover table-bordered text-center align-left" >
  <thead>
    <tr>
      <th scope="col">SID</th>
      <th scope="col">Name</th>
       <th scope="col">Room</th>
    </tr>
  </thead>
  <tbody>
 <?php

session_start();
include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
    if(isset($_POST['search']))
  {
    $key=$_POST['search'];
    $sql="SELECT * from student,Room where Room=Room_No and Room like '%$key%'"; 
  }
  else
  $sql="select * from `Student`";
 $result =mysqli_query($con,$sql);
 if($result){
 		while ($row=mysqli_fetch_assoc($result)) {
 		$sid=$row['SID'];
 		$name=$row['Name'];
 		$rm=$row['Room'];

 		echo '<tr>
      <th scope="row">'.$sid.'</th>
      <td>'.$name.'</td>
      <td>'.$rm.'</td>
</tr>';

 		}
 	}

?>
  </tbody>
</table>
</div>
<center><button class="btn btn-dark font-weight-bold"><a href="RMdisplay.php">BACK </button></center>
</body>
</html>

