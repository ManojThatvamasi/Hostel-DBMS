<?php
session_start();
include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		$id=$_GET['updateid'];
		$sql="select * from room where Room_NO='$id'";
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_assoc($result);
		$rm=$row['Room_NO'];
 		$bed=$row['No_Of_Bed'];
       

		if(isset($_POST['submit'])){
		//$EmpId = $_POST['EmpId'];
		$rm = $_POST['rmid'];
		$bed= $_POST['bed'];
		

		$sql = "update room set Room_NO='$rm',No_Of_Bed='$bed' where Room_NO='$id' ";
		$result=mysqli_query($con, $sql);
		if($result){
			//echo "<h3>Update Success</h3>";
				header('location:RMdisplay.php?update=Update Successfully');
			
		} else{
			die(mysqli_error($con));
		}
	}
		mysqli_close($con);
		?>
		<!DOCTYPE html>
<html>
<head>
	<title>Upadte Room Details</title>
	
		
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
		<link rel="stylesheet" href="form.css">
<br><br>
</head>
<body>
	<div class="container">
	<form action="" method="post">
	<h2 class="display-5 text-center">Update Room Details</h2>
	<br>
	<label>RoomId</label>
		<input type="text" id="rmid" name="rmid" class="form-control" required value=<?php echo $rm;?> >
		<br>
	<label for="Number Of Seats">Number Of Seats</label>
		<input type="text" name="bed" id="bed" class="form-control" required value=<?php echo $bed;?> ><br><br>
	<center><input type="submit" class="btn btn-success font-weight-bold" name="submit" value="UPDATE">
		<button class="btn btn-secondary font-weight-bold"><a href="RMdisplay.php" class="text-light"><-</a></button>
</center></div>
	</form>
</body>
</html>