<!DOCTYPE html>
<html>
<head>
	<title>Mess  Details</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
</head>
<body>
  <br><center>
  <h1><b>MESS DETAILS<br></b></h1></center>
<div class="container">
<form action="" method="POST" class="pull-right">
  
  <?php if(isset($_GET['update'])) { ?>
    <div class="alert alert-info w-25" role="alert">
      <?php echo $_GET['update']; ?>
      </div>
      <?php } ?>

<div class="row">
<div class="col-2">
<input type="text" name="search" placeholder="Enter Day" class="form-control"/></div>
<button class="btn btn-info font-weight-bold">SEARCH</button> 	
<div class="col"><button class="btn btn-secondary"><a href="MEdisplay.php" class="text-light font-weight-bold"><-</a></button></div>
<br></div><br>
</form>
<table  id="td" class="table table-bordered table-hover text-center" >
	<thead>
    <tr>
      
      <th scope="col">Day</th>
      <th scope="col">Break Fast<br>(7:00am-10:00am)</th>
      <th scope="col">Lunch<br>(12:30pm-3:00pm)</th>
      <th scope="col">Snacks<br>(5:00pm-6:00pm)</th>
      <th scope="col">Supper<br>(7:30pm-10:00pm)</th>
      <th scope="col">Operation</th>
    </tr>
  </thead>
  <tbody>

 <?php
session_start();
include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
	if(isset($_POST['search']))
 	{
 		$key=$_POST['search'];
 		$sql="SELECT * from mess where Day like '%$key%'";
 		
 	}
 	else
  $sql="select * from mess";
 $result =mysqli_query($con,$sql);
 if($result){
 		while ($row=mysqli_fetch_assoc($result)) {
    
   // $id=$row['Id'];
    $day=$row['Day'];
 		$bf=$row['Breakfast'];
 		$lu=$row['Lunch'];
    $snk=$row['Snacks'];
 		$sup=$row['supper'];
 		echo '<tr>
    <th scope="row">'.$day.'</th>
      <td>'.$bf.'</td>
      <td>'.$lu.'</td>
      <td>'.$snk.'</td>
      <td>'.$sup.'</td>
      <td>
  	<button class="btn btn-warning"><a href="MEupadte.php?updateid='.$day.'" class="text-light">UPDATE</a></button>
  </td>
</tr>';
 		}
 	}	
?>
  </tbody>
</table>
</div>
<center><button class="btn btn-dark font-weight-bold"><a href="boot.php">MENU</button></center>
</a>
</body>
</html>
