<!DOCTYPE html>
<html>
<head>
	<title>Employee Display</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body><br><br>
<div class="container">
    <h1 class="Display-5 font-weight-bold text-uppercase">Employee Details</h1><br>

<form action="" method="POST" class="pull-right">
<div class="row">
<div class="col-2">
<input type="text" name="search" placeholder="Enter Emp Id" class="form-control"/></div>
<button class="btn btn-info font-weight-bold">SEARCH</button>   
<div class="col"><button class="btn btn-secondary"><a href="NoOfEM.php" class="text-light font-weight-bold"><-</a></button></div>
<br></div><br>
</form>
<table class="table table-hover table-bordered text-center">
  <thead>
    <tr>
      <th scope="col">EmpID</th>
      <th scope="col">Name</th>
      <th scope="col">Address</th>
      <th scope="col">Phone</th>
      <th scope="col">DOB</th>
      <th scope="col">JOb</th>
      <th scope="col">Salary</th>
      <th scope="col">Join Date(JD)</th>
    </tr>
  </thead>
  <tbody>

 <?php
session_start();
include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
    if(isset($_POST['search']))
  {
    $key=$_POST['search'];
    $sql="SELECT * from emp where EmpId like '%$key%'";
  }
  else
  $sql="select * from `emp`";
 $result =mysqli_query($con,$sql);
 if($result){
 		while ($row=mysqli_fetch_assoc($result)) {
 		$empid=$row['EmpId'];
 		$name=$row['Name'];
 		$Adress=$row['Address'];
 		$Phone=$row['Phone'];
 		$DOB=$row['DOB'];
 		$job=$row['job'];
 		$slayr=$row['salary'];
 		$JD=$row['JD'];
 		echo '<tr>
      <th scope="row">'.$empid.'</th>
      <td>'.$name.'</td>
      <td>'.$Adress.'</td>
      <td>'.$Phone.'</td>
      <td>'.$DOB.'</td>
      <td>'.$job.'</td>
      <td>'.$slayr.'</td>
      <td>'.$JD.'</td>
      
</tr>';
 		}
 	}
?>
  </tbody>
</table>
</div>
<center><button class="btn btn-dark font-weight-bold"><a href="boot.php" >MENU</button></center>
</body>
</html>