<?php
session_start();
include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		$id=$_GET['updateid'];
		$sql="select * from mess where Day='$id'";
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_assoc($result);
		$day=$row['Day'];
 		$bf=$row['Breakfast'];
 		$lu=$row['Lunch'];
 		$snk=$row['Snacks'];
 		$sup=$row['supper'];
       
		if(isset($_POST['submit'])){

		//$day = $_POST['day'];
		$bf= $_POST['bf'];
		$lu = $_POST['lu'];
		$snk= $_POST['snk'];
		$spr= $_POST['spr'];
		

		$sql = "UPDATE mess set Breakfast='$bf',Lunch='$lu',Snacks='$snk',supper='$spr' where Day='$day' ";
		$result=mysqli_query($con, $sql);
		if($result){
			//echo "<h3>Update Success</h3>";
				header('location:MEdisplay.php?update=Update SuccessFully');
			
		} else{
			die(mysqli_error($con));
		}
	}
		mysqli_close($con);
		?>

<!DOCTYPE html>
<html>
<head>
	<title>Upadte Mess Details</title>
			<link rel="stylesheet" href="form.css">

	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
</head>
<body>
	<br><br>
	<div class="container">
		<form action="" method="post">
	<h2 class="display-5 text-center">Update Mess Details</h2>
	
		<label>Break Fast</label>
		<input type="text" name="bf" id="bf" class="form-control" value="<?php echo $bf;?>" required/><br>
		<label>Lunch</label>
		<input type="text" id="lu" name="lu" class="form-control" value="<?php echo $lu;?>" required /><br>
		<label>Snacks</label>
		<input type="text" name="snk" id="snk"  class="form-control" value="<?php echo $snk;?>" required/><br>
		<label>Supper</label>
		<input type="text" name="spr" id="spr" class="form-control" value="<?php echo $sup;?>" required/><br>

	<center><input type="submit" class="btn btn-success font-weight-bold" name="submit" value="UPDATE">
		<button class="btn btn-secondary font-weight-bold"><a href="MEdisplay.php" class="text-light"><-</a></button></center>

	</form>
</body>
</html>