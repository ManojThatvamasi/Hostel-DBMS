<?php      
session_start();
    include('connection.php');  

   if (isset($_POST['submit'])) 
   {
    $username = $_POST['user'];  
    $password = $_POST['pass'];  
      
        //to prevent from mysqli injection  
        $username = stripcslashes($username);  
        $password = stripcslashes($password);  
        $username = mysqli_real_escape_string($con, $username);  
        $password = mysqli_real_escape_string($con, $password);  
      
        $sql = "select *from login where username = '$username' and password = '$password'";  
        $result = mysqli_query($con, $sql);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
      
        $count = mysqli_num_rows($result);  
     
        if($count == 1){  
            echo "logged in"  ;  
            header("location:boot.php");
            exit();
        }  
        else{
        header("location:login.php?error=Incorrect username and password");  
            //echo "<h1> Login failed. Invalid username or password.</h1>"; 
            alert("Invalid User Login and Password"); 
        }    
        } 
?> 

<html>  
<head>  
    <title>PHP login system</title>  
    <link rel = "stylesheet" type = "text/css" href = "front.css">   
    <style type="text/css">
        label{
            width: 100px;
            display: inline-block;
        }
    </style>
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>  
<body>  
    <div id = "frm">  
      <h1>Login</h1> 
      <?php if(isset($_GET['error'])) { ?>
        <div class="alert alert-danger" role="alert">
        <?php echo $_GET['error']; ?>
        </div>
    <?php } ?> 

    <?php if(isset($_GET['logout'])) { ?>
    <div class="alert alert-secondary w-50" role="alert">
      <?php echo $_GET['logout']; ?>
      </div>
    <?php } ?>

 <form name="f1" action = "" onsubmit = "return validation()" method = "POST">           
    <label> UserName: </label>  
        <input type = "text" id ="user" name  = "user" />  <br><br>   
    <label> Password: </label>  
        <input type = "password" id ="pass" name  = "pass" />
        <br><br>    
        <input type =  "submit" id = "btn" value = "Login" name="submit" />  

        </form>  
    </div>  
    <!validation for empty field  > 
    <script>  
            function validation()  
            {  
                var id=document.f1.user.value;  
                var ps=document.f1.pass.value;  
                if(id.length=="" && ps.length=="") {  
                    alert("User Name and Password fields are empty");  
                    return false;  
                }  
                else  
                {  
                    if(id.length=="") {  
                        alert("User Name is empty");  
                        return false;  
                    }   
                    if (ps.length=="") {  
                    alert("Password field is empty");  
                    return false;  
                    }  
                }                             
            }  
        </script>  
</body>     
</html>