<?php
session_start();
   include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		if (isset($_POST['submit'])) {
			
		$sid = $_POST['sid'];
		$rc= $_POST['rc'];
		$dt = $_POST['dt'];
		$amt= $_POST['amt'];
		$sts = $_POST['sts'];
		
	
		$sql = "INSERT INTO fees VALUES ('$sid','$rc','$dt','$amt','$sts')";
		
		if(mysqli_query($con, $sql)){
			echo "<h3>data stored in a database successfully.";
				header('location:Fdisplay.php?success= successfully Added');

		} else{
			die(mysqli_error($con));
			header('location:Finsert.php?error=SID is already exists or Not found');
			
		}
				}

		// Close connection
		mysqli_close($con);
		?>

<!DOCTYPE html>
<html>
<head>
	<title>Fees DETAILS</title>
				<link rel="stylesheet" href="form.css">

		<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
	
</head>
<body><br><br>
	<div class="container">
	<form action="" method="post">
	<h2 class="display-5 text-center">Fees Add</h2>
	
	<?php if(isset($_GET['error'])) { ?>
		<div class="alert alert-danger w-75" role="alert">
  		<?php echo $_GET['error']; ?>
  		</div>
  	<?php } ?>

	<label>SID</label>
<?php
                        include('connection.php');
                        $class_result=mysqli_query($con,"SELECT SID FROM student");
                            echo '<select name="sid" class="form-control" required>';
                            echo '<option selected disabled>Select Class</option>';
                        while($row = mysqli_fetch_array($class_result)){
                            $display=$row['SID'];
                            echo '<option value="'.$display.'">'.$display.'</option>';
                        }
                        echo'</select>'
                    ?>	<label>Reciept Number</label>
		<input type="text" name="rc" class="form-control" required id="rc"/><br>
		<label>Date</label>
		<input type="Date" id="dt" class="form-control" required name="dt" /><br>
		<label>Amount</label>
		<input type="text" name="amt" class="form-control" required id="amt"/><br>
		<label>Status</label>
		<select name="sts" class="form-control" required aria-label="Default select example">
			<option selected required disabled>Choose</option>
			<option >Paid</option>
			<option>Pendding</option></select><br><br>
	<center><input type="submit" class="btn btn-success font-weight-bold" name="submit" value="ADD">
		<button class="btn btn-secondary font-weight-bold"><a href="Fdisplay.php" class="text-light"><-</a></button></center>
	</form>
</body>
</html>