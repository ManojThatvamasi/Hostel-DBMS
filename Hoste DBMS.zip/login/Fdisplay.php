<!DOCTYPE html>
<html>
<head>
	<title>JOB Details</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
</head>
<body>
<div class="container">
<button class="btn btn-primary my-5">
<a href="Finsert.php" class="text-light font-weight-bold">Add Fees </a></button>

<?php if(isset($_GET['success'])) { ?>
    <div class="alert alert-success w-25" role="alert">
      <?php echo $_GET['success']; ?>
      </div>
    <?php } ?>

    <?php if(isset($_GET['update'])) { ?>
    <div class="alert alert-info w-25" role="alert">
      <?php echo $_GET['update']; ?>
      </div>
      <?php } ?>
      <?php if(isset($_GET['delete'])) { ?>
    <div class="alert alert-danger w-25" role="alert">
      <?php echo $_GET['delete']; ?>
      </div>
      <?php } ?>
      
<form action="" method="POST" class="pull-right">
<div class="row">
<div class="col-2">
<input type="text" name="search" placeholder="Enter SID" class="form-control"/></div>
<button class="btn btn-info font-weight-bold">SEARCH</button> 	
<div class="col"><button class="btn btn-secondary"><a href="Fdisplay.php" class="text-light font-weight-bold"><-</a></button></div>
<br></div><br>
</form>
<table  id="td" class="table table-bordered table-hover text-center" >
	<thead>
    <tr>
      <th scope="col">SID</th>
      <th scope="col">Reciept Number</th>
      <th scope="col">Date</th>
      <th scope="col">Amount</th>
      <th scope="col">Status</th>
      <th scope="col">Operation</th>
    </tr>
  </thead>
  <tbody>

 <?php
session_start();
include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
	if(isset($_POST['search']))
 	{
 		$key=$_POST['search'];
 		$sql="SELECT * from fees where SID like '%$key%'";
 		
 	}
 	else
 	
  $sql="select * from fees";
 $result =mysqli_query($con,$sql);
 if($result){
 		while ($row=mysqli_fetch_assoc($result)) {
      	$sid=$row['SID'];
 		$rc=$row['Reciept_No'];
 		$dt=$row['Date'];
 		$amt=$row['Amount'];
 		$sts=$row['Status'];
 
 		echo '<tr>
    <th scope="row">'.$sid.'</th>
      <td>'.$rc.'</td>
      <td>'.$dt.'</td>
      <td>'.$amt.'</td>
      <td>'.$sts.'</td>
     
      <td>
  	<button class="btn btn-warning"><a href="Fupdate.php?updateid='.$sid.'" class="text-light">UPDATE</a></button>
  	<button class="btn btn-danger"><a href="Fdelete.php?deleteid='.$sid.'" class="text-light">DELETE</a></button>
  </td>
</tr>';
 		}
 	}	
?>
  </tbody>
</table>
</div>
<center><button class="btn btn-dark font-weight-bold"><a href="boot.php">MENU</button></center>
</a>
</body>
</html>
