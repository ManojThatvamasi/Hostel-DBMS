<?php
session_start();
   include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		if (isset($_POST['submit'])) {
			
		$EmpId = $_POST['EmpId'];
		$Name = $_POST['Name'];
		$Address= $_POST['Address'];
		$DOB = $_POST['DOB'];
		$job = $_POST['job'];
		$salary = $_POST['salary'];
		$JD = $_POST['JD'];
		$Phone=$_POST['Phone'];

		//$data= 'EmpId'.$EmpId. '&Name='.$Name. '&Address='.$Address. '&DOB='.$DOB. '&job='.$job. '&salary='.$salary. '&JD='.$JD. '&Phone='.$Phone;

		
	
		$sql = "INSERT INTO emp VALUES ('$EmpId',
			'$Name','$Address','$Phone','$DOB','$job','$salary','$JD')";
		
		if(mysqli_query($con, $sql)){
			//echo "<h3>data stored in a database successfully."
				header('location:EMdisplay.php?success=Successfully added');

		} else{
			
header("location:EMinsert.php?error=EmpID is already exit");
		die(mysqli_error($con));
		}
				
			}
		// Close connection
		mysqli_close($con);
		?>

<!DOCTYPE html>
<html>
<head>
	<title>Add Employee</title>
		<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link rel="stylesheet" href="form.css">
</head>
<body>
	<br><br>
	<div class="container">
	<form action="" method="post">
		<h2 class=" display-5 text-center">Add Employee</h2><br>
		<?php if(isset($_GET['error'])) { ?>
		<div class="alert alert-danger w-50" role="alert">
  		<?php echo $_GET['error']; ?>
  		</div>
  	<?php } ?>
		<div class="form-row">
<div class="form-group col-md-6">
		<label for="EmpId">EmpId:</label>
		<input type="text" id="EmpId" name="EmpId" class="form-control" required /><br><br>
	</div>
	<div class="form-group col-md-6">
	<label for="Name">Name:</label>
		<input type="name" name="Name" id="Name" class="form-control" required /><br><br>
	</div>
	<div class="form-group col-md-11">
	<label for="Address">Address:</label>
		<input type="text" name="Address" id="Address" class="form-control" required /><br><br>
	</div>
	<div class="form-group col-md-6">
	<label for="DOB">Date Of Birth:</label>
		<input type="date" name="DOB" id="DOB" class="form-control" required/><br><br>
	</div>
	<div class="form-group col-md-6">
<label for="Job">Job:</label>
	<?php
                        include('connection.php');
                        $class_result=mysqli_query($con,"SELECT Job_Name FROM job");
                            echo '<select name="job" class="form-control" required>';
                            echo '<option selected disabled>Select Class</option>';
                        while($row = mysqli_fetch_array($class_result)){
                            $display=$row['Job_Name'];
                            echo '<option value="'.$display.'">'.$display.'</option>';
                        }
                        echo'</select>'
                    ?>
</div><br>
<div class="form-group col-md-6">
	<label for="Phone">Phone:</label>
		<input type="text" name="Phone" id="Phone"  class="form-control"  required/><br><br>
	</div>
	<div class="form-group col-md-6">
	<label for="salary">Salary:</label>
		<input type="text" name="salary" id="salary"  class="form-control" required/><br><br>
	</div>
	<div class="form-group col-md-6">
	<label for="JD">Join Date:</label>
		<input type="date" name="JD" id="JD" class="form-control" required /><br><br>
	</div></div>
<br>
	<center><input type="submit" class="btn btn-success font-weight-bold" name="submit" value="ADD">
		<button class="btn btn-secondary font-weight-bold"><a href="EMdisplay.php" class="text-light"><-</button></center>

	</form></div>
</body>
</html>
	