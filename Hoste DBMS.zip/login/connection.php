<?php
$servername="localhost";
$username="root";
$password="";
$dbname="login";
$con= mysqli_connect($servername,$username,$password,$dbname);
if(!$con)
{
	die("Conection failed because".mysqli_connect_error());
}
?>
