 <!DOCTYPE html>
<html>
<head>
  <title>ROOM Details</title>
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="stylesheet"  href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body><br><br>
<div class="container">

<form action="" method="POST" class="pull-left">
  <h2 class="display-5">Job Details</h2>
  <br>
<div class="row">
<div class="col-7">
<input type="text" name="search" placeholder="Job Name" class="form-control"/></div>
<button class="btn btn-info font-weight-bold">SEARCH</button>   
<div class="col"><button class="btn btn-secondary"><a href="JBdetails.php" class="text-light font-weight-bold"><-</a></button></div>

<br></div><br>
</form>

<table class="table table-hover table-bordered text-center align-left" >
  <thead>
    <tr>
      <th scope="col">Emp Id</th>
      <th scope="col">Name</th>
       <th scope="col">Role</th>
    </tr>
  </thead>
  <tbody>
 <?php

session_start();
include('connection.php'); 
    if($con === false){
      die("ERROR: Could not connect. "
        . mysqli_connect_error());
    }
    if(isset($_POST['search']))
  {
    $key=$_POST['search'];
    $sql="SELECT * from emp where job like '%$key%'"; 
  }
  else
  $sql="select * from `emp`";
 $result =mysqli_query($con,$sql);
 if($result){
    while ($row=mysqli_fetch_assoc($result)) {
    $id=$row['EmpId'];
    $name=$row['Name'];
    $jb=$row['job'];

    echo '<tr>
      <th scope="row">'.$id.'</th>
      <td>'.$name.'</td>
      <td>'.$jb.'</td>
</tr>';

    }
  }

?>
  </tbody>
</table>
</div>
<center><button class="btn btn-dark font-weight-bold"><a href="JBdisplay.php">BACK </button></center>
</body>
</html>

