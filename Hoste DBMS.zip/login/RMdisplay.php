<!DOCTYPE html>
<html>
<head>
	<title>Room Details</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
<div class="container">
<button class="btn btn-primary font-weight-bold my-5">
<a href="RMinsert.php" class="text-light">Add Room </a></button>
<button class="btn btn-primary font-weight-bold my-5">
<a href="RMD.php" class="text-light">Room Details</a></button>

<?php if(isset($_GET['delete'])) { ?>
    <div class="alert alert-danger w-25" role="alert">
      <?php echo $_GET['delete']; ?>
      </div>
    <?php } ?>

<?php if(isset($_GET['update'])) { ?>
    <div class="alert alert-info w-25" role="alert">
      <?php echo $_GET['update']; ?>
      </div>
    <?php } ?>

    <?php if(isset($_GET['insert'])) { ?>
    <div class="alert alert-success w-25" role="alert">
      <?php echo $_GET['insert']; ?>
      </div>
    <?php } ?>
    <?php if(isset($_GET['error1'])) { ?>
    <div class="alert alert-danger w-25" role="alert">
      <?php echo $_GET['error1']; ?>
      </div>
    <?php } ?>


<form action="" method="POST" class="pull-right">
<div class="row">
<div class="col-2">
<input type="text" name="search" placeholder="Room No" class="form-control"/></div>
<button class="btn btn-info font-weight-bold">SEARCH</button>   
<div class="col"><button class="btn btn-secondary"><a href="RMdisplay.php" class="text-light font-weight-bold"><-</a></button></div>
<br></div><br>
</form>

<table class="table table-hover text-center table-bordered">
  <thead>
    <tr>
      <th scope="col">Room No</th>
      <th scope="col">Number Of Bed</th>
      <th scope="col">Operation</th>
    </tr>
  </thead>
  <tbody>

 <?php
session_start();
include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect."
				. mysqli_connect_error());
		}
    if(isset($_POST['search']))
  {
    $key=$_POST['search'];
    $sql="SELECT * from room where Room_No like '%$key%'";
  }
  else
  $sql="select * from room";
 $result =mysqli_query($con,$sql);
 if($result){
 		while ($row=mysqli_fetch_assoc($result)) {
 		$rm=$row['Room_NO'];
 		$bed=$row['No_Of_Bed'];
 
 		echo '<tr>
      <th scope="row">'.$rm.'</th>
      <td>'.$bed.'</td>
     
      <td>
  	<button class="btn btn-warning"><a href="RMupdate.php?updateid='.$rm.'" class="text-light">UPDATE</a></button>
  	<button class="btn btn-danger"><a href="RMdelete.php?deleteid='.$rm.'" class="text-light">DELETE</a></button>
  </td>
</tr>';
 		}
 	}
?>
  </tbody>
</table>
</div>
<center><button class="btn btn-dark font-weight-bold"><a href="boot.php" >BACK </button></center>
</body>
</html>
