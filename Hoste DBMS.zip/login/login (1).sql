-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2022 at 07:05 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 5.6.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login`
--

-- --------------------------------------------------------

--
-- Table structure for table `emp`
--

CREATE TABLE `emp` (
  `EmpId` varchar(20) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Phone` bigint(10) NOT NULL,
  `DOB` date NOT NULL,
  `job` varchar(20) NOT NULL,
  `salary` double NOT NULL,
  `JD` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp`
--

INSERT INTO `emp` (`EmpId`, `Name`, `Address`, `Phone`, `DOB`, `job`, `salary`, `JD`) VALUES
('E130', 'Guru', 'kodgu', 9874562223, '2022-01-02', 'sheffie', 12302, '2022-02-13'),
('E145', 'sdsdsc', 'kjbh', 0, '2022-01-21', 'sheffie', 5, '2022-01-20'),
('E452', 'sdfv', 'sd', 24, '2022-01-20', 'sheffie', 0, '2022-01-21'),
('Efgr', 'efv`', 'ref', 56, '2022-01-14', 'labour', 54, '2022-01-20'),
('exkcjvn', 'zmdnsfvbBAJ', 'kjnjnfk', 65555, '2022-01-08', 'labour', 56, '2022-01-13'),
('hgf', 'ytfyt2', 'hgf', 655, '2022-01-14', 'cleaner', 24, '2021-12-31'),
('r', 'reg', 'arwf', 0, '2022-01-14', 'labour', 0, '2022-01-12');

-- --------------------------------------------------------

--
-- Table structure for table `fees`
--

CREATE TABLE `fees` (
  `SID` varchar(25) NOT NULL,
  `Reciept_No` varchar(25) NOT NULL,
  `Date` date NOT NULL,
  `Amount` int(10) NOT NULL,
  `Status` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fees`
--

INSERT INTO `fees` (`SID`, `Reciept_No`, `Date`, `Amount`, `Status`) VALUES
('df', 'ghfy`', '2022-01-15', 45000, 'Paid'),
('S420', 'sdghdftjfyk', '2022-01-04', 455, 'Pendding'),
('S45', 'sdghdftjf', '2022-01-21', 4500, 'Pendding'),
('srdgf', 'zdf', '2022-01-29', 23423, 'Pendding');

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE `job` (
  `Sl_No` int(11) NOT NULL,
  `Job_Name` varchar(25) NOT NULL,
  `No_of_Emp` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`Sl_No`, `Job_Name`, `No_of_Emp`) VALUES
(10, 'cleaner', 15),
(9, 'labour', 10),
(5, 'sheffie', 5);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone` bigint(10) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `Name`, `Email`, `Phone`, `password`) VALUES
(1, 'manu', 'Manoj T N', 'manojtn.4545@gmail.com', 5446886855454, '1235');

-- --------------------------------------------------------

--
-- Table structure for table `mess`
--

CREATE TABLE `mess` (
  `id` int(2) NOT NULL,
  `Day` varchar(50) NOT NULL,
  `Breakfast` varchar(50) NOT NULL,
  `Lunch` varchar(50) NOT NULL,
  `Snacks` varchar(50) NOT NULL,
  `supper` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mess`
--

INSERT INTO `mess` (`id`, `Day`, `Breakfast`, `Lunch`, `Snacks`, `supper`) VALUES
(1, 'MONDAY', 'Upma,Kesaribath.', 'Rice-Samabar,Buttermilk', 'Tea/Coffee/Bujji', 'Chapathi(3)-curry,Rice-Samabar,Buttermilk'),
(2, 'TUESDAY', 'Lemon Rice', 'Rice-Samabar,Buttermilk', 'Tea/Coffee/Bisuit', 'Ragi Ball,Rice-Samabar,Buttermilk'),
(3, 'WEDNESDAY', 'Rice Bath', 'Rice-Samabar,Buttermilk', 'Tea/Coffee/Chips', 'Chapathi(3)-curry,Rice-Samabar,Buttermilk'),
(4, 'THURSDAY', 'Puliyogare', 'Rice-Samabar,Buttermilk', 'Tea/Coffee/Mixture', 'Ragi Ball,Rice-Samabar,Buttermilk'),
(5, 'FRIDAY', 'Idli-Sambar', 'Rice-Samabar,Buttermilk', 'Tea/Coffee/Vada', 'Chapathi(3)-curry,Rice-Samabar,Buttermilk'),
(6, 'SATURDAY', 'Pongal', 'Rice-Samabar,Buttermilk', 'Milk/Egg', 'Poori-curry,Rice-Sambar'),
(7, 'SUNDAY', 'Dosa', 'Rice-Rasam,Buttermilk', 'Milk/Egg', 'Chicken Biriyani,Veg Biriyani');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `Room_NO` varchar(10) NOT NULL,
  `No_Of_Bed` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`Room_NO`, `No_Of_Bed`) VALUES
('R123', 3),
('R14', 1),
('R42', 1),
('R420', 5),
('R485', 5),
('R546', 2);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `SID` varchar(10) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `DOB` date NOT NULL,
  `Phone` bigint(10) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `College` varchar(50) NOT NULL,
  `Course` varchar(50) NOT NULL,
  `Room` varchar(10) NOT NULL,
  `Village` varchar(25) NOT NULL,
  `Taluk` varchar(25) NOT NULL,
  `District` varchar(25) NOT NULL,
  `State` varchar(25) NOT NULL,
  `PinCode` int(6) NOT NULL,
  `Father_Name` varchar(25) NOT NULL,
  `FPhone_Number` bigint(10) NOT NULL,
  `Mother_Name` varchar(25) NOT NULL,
  `MPhone_Number` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`SID`, `Name`, `Gender`, `DOB`, `Phone`, `Email`, `College`, `Course`, `Room`, `Village`, `Taluk`, `District`, `State`, `PinCode`, `Father_Name`, `FPhone_Number`, `Mother_Name`, `MPhone_Number`) VALUES
('df', 'hvhgv', 'Male', '2022-01-27', 5446, 'gjbjru@gmail.com', 'nbvhjv', 'jhvhg', 'R546', 'jhvjh', 'vvhgvh', 'hf', 'hgffg', 4495, 'jbgjhgv', 547, 'nv', 448),
('S420', 'Srikanth', 'Male', '2022-01-13', 87945512354, 'gru@gmail.com', 'mac', '3D', 'R420', 'Yaragamballi', 'mysuru', 'mysuru', 'karnataka', 748596, 'mnop', 52768, 'pqr', 767567),
('S45', 'Prabhu', 'Male', '2022-01-06', 987458965, 'phgg@gmail.com', 'sjce', 'csadf', 'R14', 'Yaragamballi', 'Kollegala', 'Chamarajanagar', 'karnataka', 4554555, 'MNOP', 9874566, 'PQWE', 458855523),
('srdgf', 'dgfb', 'Male', '2022-01-14', 5465, 'grusd@gmail.com', 'sdfg', 'jhdgfj', 'R546', 'jhgjh', 'fufuyf', 'ffj', 'fjhg', 5, 'dfg', 54768, 'gj', 564);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `emp`
--
ALTER TABLE `emp`
  ADD PRIMARY KEY (`EmpId`),
  ADD KEY `job` (`job`);

--
-- Indexes for table `fees`
--
ALTER TABLE `fees`
  ADD PRIMARY KEY (`SID`),
  ADD UNIQUE KEY `Reciept_No` (`Reciept_No`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`Job_Name`),
  ADD UNIQUE KEY `Sl_No` (`Sl_No`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mess`
--
ALTER TABLE `mess`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Day` (`Day`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`Room_NO`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`SID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD KEY `Room` (`Room`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `job`
--
ALTER TABLE `job`
  MODIFY `Sl_No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `emp`
--
ALTER TABLE `emp`
  ADD CONSTRAINT `emp_ibfk_1` FOREIGN KEY (`job`) REFERENCES `job` (`Job_Name`);

--
-- Constraints for table `fees`
--
ALTER TABLE `fees`
  ADD CONSTRAINT `fees_ibfk_1` FOREIGN KEY (`SID`) REFERENCES `student` (`SID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`Room`) REFERENCES `room` (`Room_NO`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
