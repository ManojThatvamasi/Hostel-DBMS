<?php
session_start();
   include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		if (isset($_POST['submit'])) {
			
		$rm = $_POST['rmid'];
		$bed= $_POST['bed'];
	
		$sql = "INSERT INTO room VALUES ('$rm','$bed')";
		
		if(mysqli_query($con, $sql)){
			//echo "<h3>data stored in a database successfully.";
				header('location:RMdisplay.php?insert=Successfully Added');

		} else{
			header("location:RMinsert.php?error=Room Number is already exit");
			die(mysqli_error($con));
		}
				
			}
		// Close connection
		mysqli_close($con);
		?>

<!DOCTYPE html>
<html>
<head>
	<title>Add Student To Room</title>
		<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
				<link rel="stylesheet" href="form.css">
</head>
<body><br><br>
	<div class="container">
	<form action=""  method="post" id="form">
	<h2 class="display-5 text-center">Add Room</h2>
	
	<?php if(isset($_GET['error'])) { ?>
		<div class="alert alert-danger text-center w-75 p-3" role="alert">
  		<?php echo $_GET['error']; ?>
  		</div>
  	<?php } ?>

	<label>RoomId</label>
		<input type="text" class="form-control" name="rmid" required/><br>
	<label>Number Of Seats</label>
		<input type="text" name="bed"  class="form-control" required /><br><br>
	<center><input type="submit" class="btn btn-success font-weight-bold" name="submit" value="ADD">
		<button class="btn btn-secondary font-weight-bold"><a href="RMdisplay.php" class="text-light"><-</button></center>
	</form>
	<script src="room.js"></script>
</body>
</html>