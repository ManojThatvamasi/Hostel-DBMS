<?php
session_start();
   include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		if (isset($_POST['submit'])) {
			
		$jb = $_POST['jbid'];
		$no= $_POST['no'];
	
		$sql = "INSERT INTO job VALUES ('','$jb','$no')";
		
		if(mysqli_query($con, $sql)){
			echo "<h3>data stored in a database successfully.";
				header('location:JBdisplay.php?success=Added successfully');

		} else{
			header("location:JBinsert.php?error=Job is already exit");
			die(mysqli_error($con));
		}
				}
			}
		// Close connection
		mysqli_close($con);
		?>

<!DOCTYPE html>
<html>
<head>
	<title>JOB DETAILS</title>
		<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
		<link rel="stylesheet" href="form.css">
</head>
<body><br><br>
<div class="container">
	<form action="" method="post">
	<h2 class="display-5 text-center">Add Job</h2>
	<br>
	<?php if(isset($_GET['error'])) { ?>
		<div class="alert alert-danger text-center w-50 p-3" role="alert">
  		<?php echo $_GET['error']; ?>
  		</div>
  	<?php } ?>

	<label>Job Name</label>
		<input type="text" id="jbid" class="form-control" name="jbid" /><br>
	<label>Number Of Employee</label>
		<input type="text" name="no" class="form-control" id="no" /><br><br>
	<center><input type="submit" class="btn btn-success font-weight-bold" name="submit" value="ADD">
		<button class="btn btn-secondary font-weight-bold"><a href="JBdisplay.php" class="text-light"><-</a></button>
	</center>
	</form>
</body>
</html>