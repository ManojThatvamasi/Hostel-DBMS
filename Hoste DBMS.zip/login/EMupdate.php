<?php
session_start();
include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		$id=$_GET['updateid'];
		$sql="select * from emp where EmpId='$id'";
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_assoc($result);
		$empid=$row['EmpId'];
 		$name=$row['Name'];
 		$Adress=$row['Address'];
 		$Phone=$row['Phone'];
 		$DOB=$row['DOB'];
 		$job=$row['job'];
 		$slayr=$row['salary'];
 		$JD=$row['JD'];
       

		if(isset($_POST['submit'])){
		//$EmpId = $_POST['EmpId'];
		$Name = $_POST['Name'];
		$Address= $_POST['Address'];
		$DOB = $_POST['DOB'];
		$job = $_POST['job'];
		$salary = $_POST['salary'];
		$JD = $_POST['JD'];
		$Phone=$_POST['Phone'];

		
		$sql = "update emp set EmpID='$id',Name='$Name',Address='$Address',Phone='$Phone',DOB='$DOB',job= '$job',salary='$salary',JD='$JD' where EmpId='$id'";

		$result=mysqli_query($con, $sql);
		if($result){
			//echo "<h3>Update Success</h3>";
				header('location:EMdisplay.php?update=Update is successfully');
			
		} else{
			die(mysqli_error($con));
		}
	}
		
		mysqli_close($con);
		?>
		<!DOCTYPE html>
<html>
<head>
	<title>Upadte Employee</title>
	
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="form.css">
</head>
<body><br><br>
	<div class="container">
	<form action="" method="post">
	<h2 class="display-5 text-center">Update Employee</h2>

  	<div class="form-row">
<div class="form-group col-md-6">
	<label>Name:</label>
		<input type="text" name="Name" id="Name" class="form-control" value="<?=$row['Name']?>" required><br><br>
	</div>
	<div class="form-group col-md-6">
	<label>Address:</label>
		<input type="text" name="Address" id="Address" class="form-control" required  value=<?php echo $Adress;?> ><br><br>
	</div>
	<div class="form-group col-md-6">
	<label>Phone:</label>
		<input type="text" name="Phone" id="Phone" class="form-control" required value=<?php echo $Phone;?> ><br><br>
	</div>
	<div class="form-group col-md-6">
	<label>Date Of Birth:</label>
		<input type="date" name="DOB" id="DOB" class="form-control" required value=<?php echo $DOB;?> ><br><br>
	</div>
	<div class="form-group col-md-6">
	<label>Job:</label>
		<?php
                        include('connection.php');
                        $class_result=mysqli_query($con,"SELECT Job_Name FROM job");
                            echo '<select name="job" class="form-control" value=<?php echo $job;?>>';
                          // echo '<option selected disabled>Select Class</option>';
                           echo '<option value="'.$job.'" selected>'.$job.'</option>';
                        while($row = mysqli_fetch_array($class_result)){
                            $display=$row['Job_Name'];
                            echo '<option value="'.$display.'">'.$display.'</option>';
                        }
                        echo'</select>'
                    ?>
	</div>
	<div class="form-group col-md-6">
	<label>Salary:</label>
		<input type="text" name="salary" id="salary" class="form-control" required value=<?php echo $slayr;?> ><br><br>
	</div>
	<div class="form-group col-md-6">
	<label>Join Date:</label>
		<input type="date" name="JD" id="JD" class="form-control" required value=<?php echo $JD;?> ><br><br>
</div></div>
<br>
	<center><input type="submit" id="btn"  class="btn btn-success font-weight-bold" name="submit" value="Update">
	<button class="btn btn-secondary font-weight-bold"><a href="EMdisplay.php" class="text-light"><- </a></button>
</center>
	</form>
</body>
</html>