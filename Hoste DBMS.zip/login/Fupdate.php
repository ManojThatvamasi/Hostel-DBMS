<?php
session_start();
include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		$id=$_GET['updateid'];
		$sql="select * from fees where SID='$id'";
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_assoc($result);
		$sid=$row['SID'];
 		$rc=$row['Reciept_No'];
 		$dt=$row['Date'];
 		$amt=$row['Amount'];
 		$sts=$row['Status'];
       

		if(isset($_POST['submit'])){
		
		//$sid = $_POST['sid'];
		$rc= $_POST['rc'];
		$dt = $_POST['dt'];
		$amt= $_POST['amt'];
		$sts = $_POST['sts'];
		

		$sql = "update fees set SID='$sid',Reciept_No='$rc',Date='$dt',Amount='$amt',Status='$sts' where SID='$id' ";
		$result=mysqli_query($con, $sql);
		if($result){
			//echo "<h3>Update Success</h3>";
				header('location:Fdisplay.php?update=Update Successfully');
			
		} else{
			header('location:Fupdate.php?error=Not Found');
			die(mysqli_error($con));
		}
	}
		mysqli_close($con);
		?>
		<!DOCTYPE html>
<html>
<head>
	<title>Upadte Fees Details</title>
			<link rel="stylesheet" href="form.css">

	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
</head>
<body><br><br>
	<div class="container">
	<form action="" method="post">
	<h2 class="display-5 text-center">Update Fees Details</h2>
	 <?php if(isset($_GET['error'])) { ?>
    <div class="alert alert-danger w-50" role="alert">
      <?php echo $_GET['error']; ?>
      </div>
      <?php } ?>
	
	<label>SID</label>
		<input type="text" id="sid" name="sid" class="form-control"  disabled value=<?php echo $sid;?> required /><br>
	<label>Reciept Number</label>
		<input type="text" name="rc" id="rc" class="form-control"  value=<?php echo $rc;?> required/><br>
		<label>Date</label>
		<input type="Date" id="dt" name="dt" class="form-control"  value=<?php echo $dt;?> required /><br>
		<label>Amount</label>
		<input type="text" name="amt" id="amt" class="form-control"  value=<?php echo $amt;?> required/><br>
		<label>Status</label>
		<select  name="sts" aria-label="Default select example" class="form-control" required>
			<option selected disabled>choose</option>
			<option >Paid</option>
			<option >Pendding</option>
		</select>
		<br><br>
	<center><input type="submit" class="btn btn-success font-weight-bold" name="submit" value="UPDATE">
		<button class="btn btn-secondary font-weight-bold"><a href="Fdisplay.php" class="text-light"><-</a></button></center>
	</form>
</body>
</html>