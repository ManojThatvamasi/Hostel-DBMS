<?php
session_start();
include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		$id=$_GET['updateid'];
		$sql="select * from job where Job_Name='$id'";
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_assoc($result);
		$sl=$row['Sl_No'];
		$jb=$row['Job_Name'];
 		$emp=$row['No_of_Emp'];
       

		if(isset($_POST['submit'])){
		//$EmpId = $_POST['EmpId'];
		$jb = $_POST['jbid'];
		$no= $_POST['no'];
		

		$sql = "update job set Job_Name='$jb',No_of_Emp='$no' where Job_Name='$id' ";
		$result=mysqli_query($con, $sql);
		if($result){
			//echo "<h3>Update Success</h3>";
				header('location:JBdisplay.php?update=Successfully Updated');
			
		} else{
			die(mysqli_error($con));
		}
	}
		mysqli_close($con);
		?>
		<!DOCTYPE html>
<html>
<head>
	<title>Upadte Job Details</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="form.css">
</head>
<body><br><br>
	<div class="container">
	<form action="" method="post">
		<h2 class="display-5 text-center">Update Job Details</h2>
	<label>JOB Name:</label>
		<input type="text" id="jbId" name="jbid" class="form-control" required value=<?php echo $jb;?> ><br><br>
	<label>Number Of employee</label>
		<input type="text" name="no" id="no" class="form-control" required value=<?php echo $emp;?> ><br>
	<center><input type="submit" class="btn btn-success font-weight-bold" name="submit" value="UPDATE">
		<button class="btn btn-secondary font-weight-bold"><a href="JBdisplay.php" class="text-light"><-</a></button></div>
</center>
</form>
</body>
</html>