<?php
session_start();
include('connection.php'); 
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}

$id=$_GET['updateid'];
		$sql="select * from student where SID='$id'";
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_assoc($result);
			$sid=$row['SID'];
 		$name=$row['Name'];
 		$gender=$row['Gender'];
 		$DOB=$row['DOB'];
 		$phone=$row['Phone'];
 		$email=$row['Email'];
 		$clg=$row['College'];
 		$crs=$row['Course'];
	    $rm=$row['Room'];
	    $vl=$row['Village'];
	    $tl=$row['Taluk'];
	    $dis=$row['District'];
	    $st=$row['State'];
	    $pc=$row['PinCode'];
	    $FN=$row['Father_Name'];
	    $FPN=$row['FPhone_Number'];
	    $MN=$row['Mother_Name'];
	    $MPN=$row['MPhone_Number'];


if (isset($_POST['submit'])) {
//$sid=$_POST['F1'];
$name=$_POST['F2'];
$gender=$_POST['Gender'];
$dob=$_POST['F3'];
$phone=$_POST['F4'];
$email=$_POST['F5'];
$clg=$_POST['F6'];
$course=$_POST['F7'];
$room=$_POST['room'];
$vil=$_POST['F9'];
$tal=$_POST['F10'];
$dis=$_POST['F11'];
$state=$_POST['F12'];
$pc=$_POST['F13'];
$fn=$_POST['F14'];
$fnp=$_POST['F15'];
$mn=$_POST['F16'];
$mnp=$_POST['F17'];

$sql = "update student set Name='$name',Gender='$gender',DOB='$dob',Phone='$phone',Email='$email',College='$clg',Course='$course',Room='$room',Village='$vil', Taluk='$tal',District='$dis',State='$state', PinCode='$pc', Father_Name='$fn',FPhone_Number='$fnp',Mother_Name='$mn',MPhone_Number='$mnp' where SID='$id'";
		
		if(mysqli_query($con, $sql)){
			//echo "<h3>data stored in a database successfully."
			header('location:STdisplay.php?update=successfully Updated');
			
		} else{
			die(mysqli_error($con));
		}
	}// Close connection
		mysqli_close($con);
		?>
<!DOCTYPE html>
<html>
<head>
		<style>
			.container{
	min-height: 100vh;
	display:flex;
	justify-content: center;
	align-items: center;
	flex-direction:column;
}
.container form
{
	width:1200px;
	padding: 40px;
	border-radius: 15px;
	box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
}
.form-group
{
	margin-bottom: -35px;
}
		</style>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
	<title>Add Student Details</title>
</head>
<body>
	<div class="container">
	<form action="" method="post"  >
		<h2 class="display-5 text-center"> UPDATE STUDENT DETAILS</h2>

		<h4 class="display-5">Student Information</h4>
		<br>
		<div class="form-row">
<div class=" col-md-4 mb-3">
	<label>Student Name:</label>
	<input type="text" name="F2" required class="form-control" value=<?php echo $name;?>>
	</div>
	<div class=" col-md-2 mb-3">
	<label>Date Of Birt:</label>
		<input type="Date" name="F3" class="form-control" required value=<?php echo $DOB;?>>
	</div>
	<div class=" col-md-2 mb-3">
	<label>	Phone Number:</label>
	<input type="Number" name="F4" class="form-control" required value=<?php echo $phone;?>>
	</div>
	<div class=" col-md-4 mb-2">
	<label>Email:</label>
		<input type="Email" name="F5" class="form-control" required value=<?php echo $email;?>><br>
	</div>
	<div class="col-md-4 mb-3">
	<label>College:</label>
		<input type="text" name="F6" class="form-control" required value=<?php echo $clg;?>>
	</div>
	<div class="col-md-3 mb-2">
	<label>Course:</label>
		<input type="text" name="F7" class="form-control" required value=<?php echo $crs;?>>
	</div>
	<div class="col-md-2 mb-4">
	<label>Room:</label>
<?php
                        include('connection.php');
                        $class_result=mysqli_query($con,"SELECT Room_NO FROM room");
                            echo '<select name="room" class="form-control" required>';
                          //  echo '<option selected disabled>Select Class</option>';
                            echo '<option value="'.$rm.'" selected>'.$rm.'</option>';
                        while($row = mysqli_fetch_array($class_result)){
                            $display=$row['Room_NO'];
                            echo '<option value="'.$display.'">'.$display.'</option>';
                        }
                        echo'</select>'
                    ?>		</div>

<div class="col-md-2 mb-3">
	<label>Gender:</label><br>
	<input type="radio" name="Gender" value="Male" checked>Male
	<input type="radio" name="Gender" value="Female">Female
	<input type="radio" name="Gender" value="Other">Other
	</div>

	<div class="col-md-3 mb-3">
	<label>Village/City:</label>
		<input type="text" name="F9" class="form-control" required value=<?php echo $vl;?>>
	</div>
	<div class=" col-md-2 mb-3">
	<label>Taluk:</label>
		<input type="text" name="F10" class="form-control" required value=<?php echo $tl;?>>
	</div>
	<div class=" col-md-2 mb-3">
	<label>District:</label>
		<input type="text" name="F11" class="form-control" required value=<?php echo $dis;?>>
	</div>
	<div class=" col-md-2 mb-3">
	<label>State:</label>
		<input type="text" name="F12" class="form-control" required value=<?php echo $st;?>>
	</div>
	<div class=" col-md-2 mb-2">
	<label>PinCode:</label>
		<input type="Number" name="F13" class="form-control" required value=<?php echo $pc;?>><br>
	</div>
	
	<div class=" col-md-3 mb-4">
	<label>Father Name:</label>
		<input type="text" name="F14" class="form-control" required  value=<?php echo $FN;?>><br>
	</div>
	<div class=" col-md-2 mb-3">
	<label>Phone Number:</label>
		<input type="Number" name="F15" class="form-control" required  value=<?php echo $FPN;?>><br>
	</div>
	<div class=" col-md-3 mb-3">
	<label>Mother Name:</label>
		<input type="text" name="F16" class="form-control" required  value=<?php echo $MN;?>><br>
	</div>
	<div class=" col-md-2 mb-3">
	<label>Phone Number:</label>
		<input type="Number" name="F17" class="form-control" required  value=<?php echo $MPN;?>><br>
</div></div>
	<center><input type="submit" class="btn btn-success font-weight-bold" value="UPDATE" name="submit" />
		<button class="btn btn-secondary font-weight-bold"><a href="STdisplay.php" class="text-light"><-</a></button></center>

	</form>

</body>
</html>